<div class="container">
    <h1>Detalles del Partido</h1>
    <p>ID: <?php echo e($partido->id); ?></p>
    <p>Código: <?php echo e($partido->codigo); ?></p>
    <p>Goles Casa: <?php echo e($partido->goles_casa); ?></p>
    <p>Fecha: <?php echo e($partido->fecha); ?></p>
    <p>Goles Fuera: <?php echo e($partido->goles_fuera); ?></p>
    <a href="<?php echo e(route('partidos.index')); ?>" class="btn btn-secondary">Volver</a>
</div>
<?php /**PATH C:\xampp\htdocs\ejercicio16\resources\views/partidos/show.blade.php ENDPATH**/ ?>