<div class="container">
    <h1>Lista de Partidos</h1>
    <a href="<?php echo e(route('partidos.create')); ?>" class="btn btn-primary">Crear Partido</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Goles Casa</th>
                <th>Fecha</th>
                <th>Goles Fuera</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $partido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($partido->id); ?></td>
                    <td><?php echo e($partido->codigo); ?></td>
                    <td><?php echo e($partido->goles_casa); ?></td>
                    <td><?php echo e($partido->fecha); ?></td>
                    <td><?php echo e($partido->goles_fuera); ?></td>
                    <td>
                        <a href="<?php echo e(route('partidos.show', $partido->id)); ?>" class="btn btn-info">Ver</a>
                        <a href="<?php echo e(route('partidos.edit', $partido->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('partidos.destroy', $partido->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\ejercicio16\resources\views/partidos/index.blade.php ENDPATH**/ ?>