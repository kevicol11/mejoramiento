<?php

namespace App\Http\Controllers;

use App\Models\Gol;
use Illuminate\Http\Request;

class GolController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Gol $gol)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Gol $gol)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Gol $gol)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Gol $gol)
    {
        //
    }
}
