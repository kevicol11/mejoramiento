

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Lista de Viajeros</h1>

    <div class="mb-3">
        <a href="<?php echo e(route('crud.create')); ?>" class="btn btn-primary">Crear Viajero</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="list-group">
        <?php $__empty_1 = true; $__currentLoopData = $viajeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viajero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="list-group-item list-group-item-action flex-column align-items-start">
                <div class="d-flex w-100 justify-content-between">
                    <h5 class="mb-1"><?php echo e($viajero->nombre); ?></h5>
                    <small>ID: <?php echo e($viajero->id); ?></small>
                </div>
                <p class="mb-1">Dirección: <?php echo e($viajero->direccion); ?></p>
                <p class="mb-1">Teléfono: <?php echo e($viajero->telefono); ?></p>
                <div class="mt-2">
                    <a href="<?php echo e(route('viajeros.show', $viajero->id)); ?>" class="btn btn-info btn-sm">Ver</a>
                    <a href="<?php echo e(route('viajeros.edit', $viajero->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <form action="<?php echo e(route('viajeros.destroy', $viajero->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar este viajero?')">Eliminar</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="list-group-item">
                No hay viajeros registrados.
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Viaje-app\resources\views/crud/listar.blade.php ENDPATH**/ ?>