

<div class="container">
    <h1>Ingresar viajero</h1>
    <form action="<?php echo e(route('viajero.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>
            nombre:
            <input type="text" name="nombre" required>
        </label>
        <br>
        <label>
            direccion:
            <input type="text" name="direccion" required>
        </label>
        <br>
        <label>
            telefono:
            <input type="text" name="telefono" required>
        </label>
        <br>
        <button type="submit">Ingresar viajero</button>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\Viaje-app\resources\views/crud/create.blade.php ENDPATH**/ ?>