<h1>Viajeros</h1>

<ul>
    <?php $__currentLoopData = $viajeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viajero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($viajero->nombre); ?> (<?php echo e($viajero->direccion); ?>)
            <a href="<?php echo e(route('viajeros.show', $viajero->id)); ?>">Ver</a>
            <a href="<?php echo e(route('viajeros.edit', $viajero->id)); ?>">Editar</a>
            <form action="<?php echo e(route('viajeros.destroy', $viajero->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit">Eliminar</button>
            </form>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<a href="<?php echo e(route('viajeros.create')); ?>">Crear nuevo viajero</a><?php /**PATH C:\xampp\htdocs\Viaje-app\resources\views/viajeros/index.blade.php ENDPATH**/ ?>