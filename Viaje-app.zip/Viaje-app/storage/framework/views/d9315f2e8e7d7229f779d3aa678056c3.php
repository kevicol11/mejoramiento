<h1>este es el viajero <?php echo e($viajero->id); ?></h1>
<h2>nombre: <?php echo e($viajero->nombre); ?></h2>
<h2>direccion: <?php echo e($viajero->direccion); ?></h2>
<h2>telefono: <?php echo e($viajero->telefono); ?></h2>
<a href="<?php echo e(route('viajero.edit', $viajero)); ?>">Editar viajero</a>
<?php /**PATH C:\xampp\htdocs\Viaje-app\resources\views/crud/show.blade.php ENDPATH**/ ?>