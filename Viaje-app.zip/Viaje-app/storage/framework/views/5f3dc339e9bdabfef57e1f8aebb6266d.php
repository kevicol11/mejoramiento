<h1>Viajero <?php echo e($viajero->nombre); ?></h1>

<p>Dirección: <?php echo e($viajero->direccion); ?></p>
<p>Teléfono: <?php echo e($viajero->telefono); ?></p>

<a href="<?php echo e(route('viajeros.index')); ?>">Volver a la lista de viajeros</a><?php /**PATH C:\xampp\htdocs\Viaje-app\resources\views/viajeros/show.blade.php ENDPATH**/ ?>